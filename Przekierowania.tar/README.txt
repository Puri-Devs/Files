Foldery z przekierowaniami włożyć do  głównego katalogu
